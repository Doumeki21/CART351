$(window).on("load", function () {
    $("#loader-wrapper").fadeOut(700);
  });