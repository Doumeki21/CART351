window.onload = function () {
    setTimeout(function () {
      document.getElementById("fadein").remove();
    }, 1000);
  };