//1st question

$(window).on("load", function () {
  $('#question1').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 1250 && $(this).scrollTop() < 2000) {
    $('#question1').fadeIn();
  } else {
    $('#question1').fadeOut();
  }
});

//2nd question

$(window).on("load", function () {
  $('#question2').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 2450 && $(this).scrollTop() < 3000) {
    $('#question2').fadeIn();
  } else {
    $('#question2').fadeOut();
  }
});

//3rd question

$(window).on("load", function () {
  $('#question3').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 3250 && $(this).scrollTop() < 3300) {
    $('#question3').fadeIn();
  } else {
    $('#question3').fadeOut();
  }
});

//4th question

$(window).on("load", function () {
  $('#question4').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 3850 && $(this).scrollTop() < 4300) {
    $('#question4').fadeIn();
  } else {
    $('#question4').fadeOut();
  }
});

//5th question

$(window).on("load", function () {
  $('#question5').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 5000 && $(this).scrollTop() < 5600) {
    $('#question5').fadeIn();
  } else {
    $('#question5').fadeOut();
  }
});

//6th question

$(window).on("load", function () {
  $('#question6').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 6050 && $(this).scrollTop() < 11050) {
    $('#question6').fadeIn();
  } else {
    $('#question6').fadeOut();
  }
});

//7th question

$(window).on("load", function () {
  $('#question7').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 11300 && $(this).scrollTop() < 15300) {
    $('#question7').fadeIn();
  } else {
    $('#question7').fadeOut();
  }
});

//8th question

$(window).on("load", function () {
  $('#question8').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 15600 && $(this).scrollTop() < 17600) {
    $('#question8').fadeIn();
  } else {
    $('#question8').fadeOut();
  }
});

//9th question

$(window).on("load", function () {
  $('#question9').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 17900 && $(this).scrollTop() < 19900) {
    $('#question9').fadeIn();
  } else {
    $('#question9').fadeOut();
  }
});

//10th question

$(window).on("load", function () {
  $('#question10').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 20300 && $(this).scrollTop() < 25300) {
    $('#question10').fadeIn();
  } else {
    $('#question10').fadeOut();
  }
});

//11th question

$(window).on("load", function () {
  $('#question11').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 25600 && $(this).scrollTop() < 30600) {
    $('#question11').fadeIn();
  } else {
    $('#question11').fadeOut();
  }
});

//12th question

$(window).on("load", function () {
  $('#question12').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 30900 && $(this).scrollTop() < 35200) {
    $('#question12').fadeIn();
  } else {
    $('#question12').fadeOut();
  }
});

//13th question

$(window).on("load", function () {
  $('#question13').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 35600 && $(this).scrollTop() < 40500) {
    $('#question13').fadeIn();
  } else {
    $('#question13').fadeOut();
  }
});

//14th question

$(window).on("load", function () {
  $('#question14').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 40900 && $(this).scrollTop() < 45100) {
    $('#question14').fadeIn();
  } else {
    $('#question14').fadeOut();
  }
});

//15th question

$(window).on("load", function () {
  $('#question15').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 45500 && $(this).scrollTop() < 50500) {
    $('#question15').fadeIn();
  } else {
    $('#question15').fadeOut();
  }
});

//16th question

$(window).on("load", function () {
  $('#question16').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 50900 && $(this).scrollTop() < 55900) {
    $('#question16').fadeIn();
  } else {
    $('#question16').fadeOut();
  }
});

//17th question

$(window).on("load", function () {
  $('#question17').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 61300 && $(this).scrollTop() < 66300) {
    $('#question17').fadeIn();
  } else {
    $('#question17').fadeOut();
  }
});

//18th question

$(window).on("load", function () {
  $('#question18').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 66800 && $(this).scrollTop() < 71600) {
    $('#question18').fadeIn();
  } else {
    $('#question18').fadeOut();
  }
});

//19th question

$(window).on("load", function () {
  $('#question19').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 72000 && $(this).scrollTop() < 77000) {
    $('#question19').fadeIn();
  } else {
    $('#question19').fadeOut();
  }
});

//20th question

$(window).on("load", function () {
  $('#question20').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 77400 && $(this).scrollTop() < 82400) {
    $('#question20').fadeIn();
  } else {
    $('#question20').fadeOut();
  }
});

//21st question

$(window).on("load", function () {
  $('#question21').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 82900 && $(this).scrollTop() < 87900) {
    $('#question21').fadeIn();
  } else {
    $('#question21').fadeOut();
  }
});

//22nd question

$(window).on("load", function () {
  $('#question22').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 88300 && $(this).scrollTop() < 92000) {
    $('#question22').fadeIn();
  } else {
    $('#question22').fadeOut();
  }
});

//23rd question

$(window).on("load", function () {
  $('#question23').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 92700 && $(this).scrollTop() < 95000) {
    $('#question23').fadeIn();
  } else {
    $('#question23').fadeOut();
  }
});

//24th question

$(window).on("load", function () {
  $('#question24').hide();
});

$(window).scroll(function() { 
  if ($(this).scrollTop() > 95400 && $(this).scrollTop() < 100000) {
    $('#question24').fadeIn();
  } else {
    $('#question24').fadeOut();
  }
});

$(window).on("load", function () {
  $('#vis1').hide();
});

$(document).ready(function(){ 
  $(".button-submit").click(function() { 
    $("#vis1").fadeIn("slow");
    $('#submissionform').remove();
  });
});