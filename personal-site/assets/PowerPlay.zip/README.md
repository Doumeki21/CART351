# PowerPlay Documentation / Shayne La Rocque & Olenka Yuen
Protoype of the final project for CART351
---
Nov 2
Worked on creating a baseline for the project: Implented JQuery, Boostrap, and Popper.js. Also implemented a simple 3 column framework for the site as a placeholder. Added extensive HTML Head meta tags and Favicon styling.
