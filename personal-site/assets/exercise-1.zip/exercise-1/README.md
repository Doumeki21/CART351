# NOTES

**Reference**
- [Canvas centering](https://stackoverflow.com/questions/5127937/how-to-center-canvas-in-html5)